package com.tnsif.PlacementManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
